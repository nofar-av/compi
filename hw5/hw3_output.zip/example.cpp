// #include <memory>
// #include <iostream>
// using namespace std;
// int main() {
    
//     shared_ptr<int> a = make_shared<int>(nullptr);
//     cout << "worked";
//     return 0;
// }